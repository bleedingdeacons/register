using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TheBleedingDeacons.Unity.Data.Entities;

namespace TheBleedingDeacons.Intergroup.Register.Models
{
    public record MeetingUpdatedMessage(Meeting meeting);
}
